data: stores all data used in the application, from both local and remote sources.
