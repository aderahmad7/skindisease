package com.example.skindisease.domain.model

data class Todo(
    val id: Int,
    val completed: Boolean,
    val title: String
)
